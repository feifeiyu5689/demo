package com.pocket.paperReader;

import anywheresoftware.b4a.BA;
import anywheresoftware.b4a.pc.*;

public class main_subs_0 {


public static void  _activity_create(RemoteObject _firsttime) throws Exception{
try {
		Debug.PushSubsStack("Activity_Create (main) ","main",0,main.mostCurrent.activityBA,main.mostCurrent,24);
if (RapidSub.canDelegate("activity_create")) { com.pocket.paperReader.main.remoteMe.runUserSub(false, "main","activity_create", _firsttime); return;}
ResumableSub_Activity_Create rsub = new ResumableSub_Activity_Create(null,_firsttime);
rsub.resume(null, null);
}
catch (Exception e) {
			throw Debug.ErrorCaught(e);
		} 
finally {
			Debug.PopSubsStack();
		}}
public static class ResumableSub_Activity_Create extends BA.ResumableSub {
public ResumableSub_Activity_Create(com.pocket.paperReader.main parent,RemoteObject _firsttime) {
this.parent = parent;
this._firsttime = _firsttime;
}
java.util.LinkedHashMap<String, Object> rsLocals = new java.util.LinkedHashMap<String, Object>();
com.pocket.paperReader.main parent;
RemoteObject _firsttime;
RemoteObject _jo = RemoteObject.declareNull("anywheresoftware.b4j.object.JavaObject");
RemoteObject _rx = RemoteObject.declareNull("anywheresoftware.b4a.agraham.reflection.Reflection");
RemoteObject _r = RemoteObject.declareNull("anywheresoftware.b4a.objects.RuntimePermissions");
RemoteObject _list = RemoteObject.declareNull("anywheresoftware.b4a.objects.collections.List");
RemoteObject _rp = RemoteObject.declareNull("anywheresoftware.b4a.objects.RuntimePermissions");
int _i = 0;
RemoteObject _b = RemoteObject.createImmutable(false);
RemoteObject _permission = RemoteObject.createImmutable("");
RemoteObject _result = RemoteObject.createImmutable(false);
int step18;
int limit18;

@Override
public void resume(BA ba, RemoteObject result) throws Exception{
try {
		Debug.PushSubsStack("Activity_Create (main) ","main",0,main.mostCurrent.activityBA,main.mostCurrent,24);
Debug.locals = rsLocals;Debug.currentSubFrame.locals = rsLocals;

    while (true) {
        switch (state) {
            case -1:
return;

case 0:
//C
this.state = 1;
Debug.locals.put("FirstTime", _firsttime);
 BA.debugLineNum = 25;BA.debugLine="Dim jo As JavaObject";
Debug.ShouldStop(16777216);
_jo = RemoteObject.createNew ("anywheresoftware.b4j.object.JavaObject");Debug.locals.put("jo", _jo);
 BA.debugLineNum = 26;BA.debugLine="jo.InitializeStatic(\"com.qq.e.comm.managers.GDTAd";
Debug.ShouldStop(33554432);
_jo.runVoidMethod ("InitializeStatic",(Object)(RemoteObject.createImmutable("com.qq.e.comm.managers.GDTAdSdk.GDTAdSdk")));
 BA.debugLineNum = 27;BA.debugLine="Dim rx As Reflector";
Debug.ShouldStop(67108864);
_rx = RemoteObject.createNew ("anywheresoftware.b4a.agraham.reflection.Reflection");Debug.locals.put("rx", _rx);
 BA.debugLineNum = 28;BA.debugLine="jo.RunMethod(\"init\", Array As Object( rx.GetCo";
Debug.ShouldStop(134217728);
_jo.runVoidMethod ("RunMethod",(Object)(BA.ObjectToString("init")),(Object)(RemoteObject.createNewArray("Object",new int[] {2},new Object[] {(_rx.runMethod(false,"GetContext",main.processBA)),(RemoteObject.createImmutable("1200794210"))})));
 BA.debugLineNum = 35;BA.debugLine="Activity.LoadLayout(\"Layout\")";
Debug.ShouldStop(4);
parent.mostCurrent._activity.runMethodAndSync(false,"LoadLayout",(Object)(RemoteObject.createImmutable("Layout")),main.mostCurrent.activityBA);
 BA.debugLineNum = 36;BA.debugLine="Log(\"\" &DateTime.Time(DateTime.Now) )";
Debug.ShouldStop(8);
parent.mostCurrent.__c.runVoidMethod ("LogImpl","8131084",RemoteObject.concat(RemoteObject.createImmutable(""),parent.mostCurrent.__c.getField(false,"DateTime").runMethod(true,"Time",(Object)(parent.mostCurrent.__c.getField(false,"DateTime").runMethod(true,"getNow")))),0);
 BA.debugLineNum = 37;BA.debugLine="Log(\"********************************************";
Debug.ShouldStop(16);
parent.mostCurrent.__c.runVoidMethod ("LogImpl","8131085",RemoteObject.createImmutable("********************************************"),0);
 BA.debugLineNum = 38;BA.debugLine="Dim r As RuntimePermissions";
Debug.ShouldStop(32);
_r = RemoteObject.createNew ("anywheresoftware.b4a.objects.RuntimePermissions");Debug.locals.put("r", _r);
 BA.debugLineNum = 40;BA.debugLine="Dim list As List";
Debug.ShouldStop(128);
_list = RemoteObject.createNew ("anywheresoftware.b4a.objects.collections.List");Debug.locals.put("list", _list);
 BA.debugLineNum = 41;BA.debugLine="list.Initialize";
Debug.ShouldStop(256);
_list.runVoidMethod ("Initialize");
 BA.debugLineNum = 42;BA.debugLine="list.Add(r.PERMISSION_READ_PHONE_STATE)";
Debug.ShouldStop(512);
_list.runVoidMethod ("Add",(Object)((_r.getField(true,"PERMISSION_READ_PHONE_STATE"))));
 BA.debugLineNum = 43;BA.debugLine="list.Add(r.PERMISSION_WRITE_EXTERNAL_STORAGE)";
Debug.ShouldStop(1024);
_list.runVoidMethod ("Add",(Object)((_r.getField(true,"PERMISSION_WRITE_EXTERNAL_STORAGE"))));
 BA.debugLineNum = 44;BA.debugLine="list.Add( r.PERMISSION_ACCESS_COARSE_LOCATION )";
Debug.ShouldStop(2048);
_list.runVoidMethod ("Add",(Object)((_r.getField(true,"PERMISSION_ACCESS_COARSE_LOCATION"))));
 BA.debugLineNum = 45;BA.debugLine="list.Add( r.PERMISSION_ACCESS_FINE_LOCATION)";
Debug.ShouldStop(4096);
_list.runVoidMethod ("Add",(Object)((_r.getField(true,"PERMISSION_ACCESS_FINE_LOCATION"))));
 BA.debugLineNum = 48;BA.debugLine="Log(\"********************************************";
Debug.ShouldStop(32768);
parent.mostCurrent.__c.runVoidMethod ("LogImpl","8131096",RemoteObject.createImmutable("********************************************rights"),0);
 BA.debugLineNum = 50;BA.debugLine="If list=Null Then list.Initialize";
Debug.ShouldStop(131072);
if (true) break;

case 1:
//if
this.state = 6;
if (RemoteObject.solveBoolean("n",_list)) { 
this.state = 3;
;}if (true) break;

case 3:
//C
this.state = 6;
_list.runVoidMethod ("Initialize");
if (true) break;

case 6:
//C
this.state = 7;
;
 BA.debugLineNum = 51;BA.debugLine="Dim rp As RuntimePermissions";
Debug.ShouldStop(262144);
_rp = RemoteObject.createNew ("anywheresoftware.b4a.objects.RuntimePermissions");Debug.locals.put("rp", _rp);
 BA.debugLineNum = 52;BA.debugLine="For i=0 To list.Size-1";
Debug.ShouldStop(524288);
if (true) break;

case 7:
//for
this.state = 14;
step18 = 1;
limit18 = RemoteObject.solve(new RemoteObject[] {_list.runMethod(true,"getSize"),RemoteObject.createImmutable(1)}, "-",1, 1).<Integer>get().intValue();
_i = 0 ;
Debug.locals.put("i", _i);
this.state = 15;
if (true) break;

case 15:
//C
this.state = 14;
if ((step18 > 0 && _i <= limit18) || (step18 < 0 && _i >= limit18)) this.state = 9;
if (true) break;

case 16:
//C
this.state = 15;
_i = ((int)(0 + _i + step18)) ;
Debug.locals.put("i", _i);
if (true) break;

case 9:
//C
this.state = 10;
 BA.debugLineNum = 53;BA.debugLine="Dim b As Boolean=rp.Check(list.Get(i))";
Debug.ShouldStop(1048576);
_b = _rp.runMethod(true,"Check",(Object)(BA.ObjectToString(_list.runMethod(false,"Get",(Object)(BA.numberCast(int.class, _i))))));Debug.locals.put("b", _b);Debug.locals.put("b", _b);
 BA.debugLineNum = 54;BA.debugLine="If b=False Then";
Debug.ShouldStop(2097152);
if (true) break;

case 10:
//if
this.state = 13;
if (RemoteObject.solveBoolean("=",_b,parent.mostCurrent.__c.getField(true,"False"))) { 
this.state = 12;
}if (true) break;

case 12:
//C
this.state = 13;
 BA.debugLineNum = 55;BA.debugLine="rp.CheckAndRequest( list.Get(i) )";
Debug.ShouldStop(4194304);
_rp.runVoidMethod ("CheckAndRequest",main.processBA,(Object)(BA.ObjectToString(_list.runMethod(false,"Get",(Object)(BA.numberCast(int.class, _i))))));
 BA.debugLineNum = 56;BA.debugLine="Wait For Activity_PermissionResult (Permission";
Debug.ShouldStop(8388608);
parent.mostCurrent.__c.runVoidMethod ("WaitFor","activity_permissionresult", main.processBA, anywheresoftware.b4a.pc.PCResumableSub.createDebugResumeSub(this, "main", "activity_create"), null);
this.state = 17;
return;
case 17:
//C
this.state = 13;
_permission = (RemoteObject) result.getArrayElement(true,RemoteObject.createImmutable(0));Debug.locals.put("Permission", _permission);
_result = (RemoteObject) result.getArrayElement(true,RemoteObject.createImmutable(1));Debug.locals.put("Result", _result);
;
 if (true) break;

case 13:
//C
this.state = 16;
;
 if (true) break;
if (true) break;

case 14:
//C
this.state = -1;
Debug.locals.put("i", _i);
;
 BA.debugLineNum = 59;BA.debugLine="Log(\"*******************************************";
Debug.ShouldStop(67108864);
parent.mostCurrent.__c.runVoidMethod ("LogImpl","8131107",RemoteObject.createImmutable("********************************************2"),0);
 BA.debugLineNum = 60;BA.debugLine="ad.Initialize(\"\")";
Debug.ShouldStop(134217728);
parent.mostCurrent._ad.runVoidMethod ("Initialize",main.mostCurrent.activityBA,(Object)(RemoteObject.createImmutable("")));
 BA.debugLineNum = 61;BA.debugLine="Activity.AddView(ad,0,50%y,100%x,50%y)";
Debug.ShouldStop(268435456);
parent.mostCurrent._activity.runVoidMethod ("AddView",(Object)((parent.mostCurrent._ad.getObject())),(Object)(BA.numberCast(int.class, 0)),(Object)(parent.mostCurrent.__c.runMethod(true,"PerYToCurrent",(Object)(BA.numberCast(float.class, 50)),main.mostCurrent.activityBA)),(Object)(parent.mostCurrent.__c.runMethod(true,"PerXToCurrent",(Object)(BA.numberCast(float.class, 100)),main.mostCurrent.activityBA)),(Object)(parent.mostCurrent.__c.runMethod(true,"PerYToCurrent",(Object)(BA.numberCast(float.class, 50)),main.mostCurrent.activityBA)));
 BA.debugLineNum = 62;BA.debugLine="ad.Color=Colors.Cyan";
Debug.ShouldStop(536870912);
parent.mostCurrent._ad.runVoidMethod ("setColor",parent.mostCurrent.__c.getField(false,"Colors").getField(true,"Cyan"));
 BA.debugLineNum = 63;BA.debugLine="End Sub";
Debug.ShouldStop(1073741824);
if (true) break;

            }
        }
    }
catch (Exception e) {
			throw Debug.ErrorCaught(e);
		} 
finally {
			Debug.PopSubsStack();
		}}
}
public static void  _activity_permissionresult(RemoteObject _permission,RemoteObject _result) throws Exception{
}
public static RemoteObject  _activity_pause(RemoteObject _userclosed) throws Exception{
try {
		Debug.PushSubsStack("Activity_Pause (main) ","main",0,main.mostCurrent.activityBA,main.mostCurrent,69);
if (RapidSub.canDelegate("activity_pause")) { return com.pocket.paperReader.main.remoteMe.runUserSub(false, "main","activity_pause", _userclosed);}
Debug.locals.put("UserClosed", _userclosed);
 BA.debugLineNum = 69;BA.debugLine="Sub Activity_Pause (UserClosed As Boolean)";
Debug.ShouldStop(16);
 BA.debugLineNum = 71;BA.debugLine="End Sub";
Debug.ShouldStop(64);
return RemoteObject.createImmutable("");
}
catch (Exception e) {
			throw Debug.ErrorCaught(e);
		} 
finally {
			Debug.PopSubsStack();
		}}
public static RemoteObject  _activity_resume() throws Exception{
try {
		Debug.PushSubsStack("Activity_Resume (main) ","main",0,main.mostCurrent.activityBA,main.mostCurrent,65);
if (RapidSub.canDelegate("activity_resume")) { return com.pocket.paperReader.main.remoteMe.runUserSub(false, "main","activity_resume");}
 BA.debugLineNum = 65;BA.debugLine="Sub Activity_Resume";
Debug.ShouldStop(1);
 BA.debugLineNum = 67;BA.debugLine="End Sub";
Debug.ShouldStop(4);
return RemoteObject.createImmutable("");
}
catch (Exception e) {
			throw Debug.ErrorCaught(e);
		} 
finally {
			Debug.PopSubsStack();
		}}
public static RemoteObject  _button1_click() throws Exception{
try {
		Debug.PushSubsStack("Button1_Click (main) ","main",0,main.mostCurrent.activityBA,main.mostCurrent,74);
if (RapidSub.canDelegate("button1_click")) { return com.pocket.paperReader.main.remoteMe.runUserSub(false, "main","button1_click");}
RemoteObject _jo = RemoteObject.declareNull("anywheresoftware.b4j.object.JavaObject");
RemoteObject _r = RemoteObject.declareNull("anywheresoftware.b4a.agraham.reflection.Reflection");
 BA.debugLineNum = 74;BA.debugLine="Sub Button1_Click";
Debug.ShouldStop(512);
 BA.debugLineNum = 75;BA.debugLine="Dim jo As JavaObject";
Debug.ShouldStop(1024);
_jo = RemoteObject.createNew ("anywheresoftware.b4j.object.JavaObject");Debug.locals.put("jo", _jo);
 BA.debugLineNum = 76;BA.debugLine="jo.InitializeStatic(\"com.jksoft.gdtlibrary.tool\")";
Debug.ShouldStop(2048);
_jo.runVoidMethod ("InitializeStatic",(Object)(RemoteObject.createImmutable("com.jksoft.gdtlibrary.tool")));
 BA.debugLineNum = 77;BA.debugLine="Dim r As Reflector";
Debug.ShouldStop(4096);
_r = RemoteObject.createNew ("anywheresoftware.b4a.agraham.reflection.Reflection");Debug.locals.put("r", _r);
 BA.debugLineNum = 78;BA.debugLine="r.GetActivity";
Debug.ShouldStop(8192);
_r.runVoidMethod ("GetActivity",main.processBA);
 BA.debugLineNum = 79;BA.debugLine="jo.RunMethod(\"fetchSplashAD\",Array As Object( r.G";
Debug.ShouldStop(16384);
_jo.runVoidMethod ("RunMethod",(Object)(BA.ObjectToString("fetchSplashAD")),(Object)(RemoteObject.createNewArray("Object",new int[] {4},new Object[] {(_r.runMethod(false,"GetActivity",main.processBA)),(main.mostCurrent._ad.getObject()),RemoteObject.createImmutable(("6043886927251212")),RemoteObject.createImmutable((3000))})));
 BA.debugLineNum = 80;BA.debugLine="End Sub";
Debug.ShouldStop(32768);
return RemoteObject.createImmutable("");
}
catch (Exception e) {
			throw Debug.ErrorCaught(e);
		} 
finally {
			Debug.PopSubsStack();
		}}
public static RemoteObject  _globals() throws Exception{
 //BA.debugLineNum = 20;BA.debugLine="Sub Globals";
 //BA.debugLineNum = 21;BA.debugLine="Dim ad As Panel";
main.mostCurrent._ad = RemoteObject.createNew ("anywheresoftware.b4a.objects.PanelWrapper");
 //BA.debugLineNum = 22;BA.debugLine="End Sub";
return RemoteObject.createImmutable("");
}

public static void initializeProcessGlobals() {
    
    if (main.processGlobalsRun == false) {
	    main.processGlobalsRun = true;
		try {
		        main_subs_0._process_globals();
starter_subs_0._process_globals();
main.myClass = BA.getDeviceClass ("com.pocket.paperReader.main");
starter.myClass = BA.getDeviceClass ("com.pocket.paperReader.starter");
fileprovider.myClass = BA.getDeviceClass ("com.pocket.paperReader.fileprovider");
		
        } catch (Exception e) {
			throw new RuntimeException(e);
		}
    }
}public static RemoteObject  _process_globals() throws Exception{
 //BA.debugLineNum = 16;BA.debugLine="Sub Process_Globals";
 //BA.debugLineNum = 17;BA.debugLine="Private xui As XUI";
main._xui = RemoteObject.createNew ("anywheresoftware.b4a.objects.B4XViewWrapper.XUI");
 //BA.debugLineNum = 18;BA.debugLine="End Sub";
return RemoteObject.createImmutable("");
}
}