
package com.pocket.paperReader;

import anywheresoftware.b4a.pc.PCBA;
import anywheresoftware.b4a.pc.RemoteObject;

public class fileprovider {
    public static RemoteObject myClass;
	public fileprovider() {
	}
    public static PCBA staticBA = new PCBA(null, fileprovider.class);

public static RemoteObject __c = RemoteObject.declareNull("anywheresoftware.b4a.keywords.Common");
public static RemoteObject _sharedfolder = RemoteObject.createImmutable("");
public static RemoteObject _usefileprovider = RemoteObject.createImmutable(false);
public static RemoteObject _rp = RemoteObject.declareNull("anywheresoftware.b4a.objects.RuntimePermissions");
public static RemoteObject _ui = RemoteObject.declareNull("b4a.uisource.ui");
public static RemoteObject _uxt = RemoteObject.declareNull("b4a.uisource.uxt");
public static RemoteObject _udb = RemoteObject.declareNull("b4a.uisource.udb");
public static RemoteObject _uistyle = RemoteObject.declareNull("b4a.uisource.uistyle");
public static RemoteObject _u3 = RemoteObject.declareNull("b4a.uisource.u3");
public static RemoteObject _patch_createrowviews_bydesc = RemoteObject.declareNull("b4a.uisource.patch_createrowviews_bydesc");
public static RemoteObject _pubdata = RemoteObject.declareNull("b4a.uisource.pubdata");
public static RemoteObject _uipermissionactivity = RemoteObject.declareNull("b4a.uisource.uipermissionactivity");
public static RemoteObject _dateutils = RemoteObject.declareNull("b4a.example.dateutils");
public static com.pocket.paperReader.main _main = null;
public static com.pocket.paperReader.starter _starter = null;
public static Object[] GetGlobals(RemoteObject _ref) throws Exception {
		return new Object[] {"DateUtils",_ref.getField(false, "_dateutils"),"patch_createRowViews_byDesc",_ref.getField(false, "_patch_createrowviews_bydesc"),"pubdata",_ref.getField(false, "_pubdata"),"rp",_ref.getField(false, "_rp"),"SharedFolder",_ref.getField(false, "_sharedfolder"),"u3",_ref.getField(false, "_u3"),"udb",_ref.getField(false, "_udb"),"ui",_ref.getField(false, "_ui"),"uiPermissionActivity",_ref.getField(false, "_uipermissionactivity"),"uiStyle",_ref.getField(false, "_uistyle"),"UseFileProvider",_ref.getField(false, "_usefileprovider"),"uxt",_ref.getField(false, "_uxt")};
}
}