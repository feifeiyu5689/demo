
package com.pocket.paperReader;

import java.io.IOException;
import anywheresoftware.b4a.BA;
import anywheresoftware.b4a.pc.PCBA;
import anywheresoftware.b4a.pc.RDebug;
import anywheresoftware.b4a.pc.RemoteObject;
import anywheresoftware.b4a.pc.RDebug.IRemote;
import anywheresoftware.b4a.pc.Debug;
import anywheresoftware.b4a.pc.B4XTypes.B4XClass;
import anywheresoftware.b4a.pc.B4XTypes.DeviceClass;

public class starter implements IRemote{
	public static starter mostCurrent;
	public static RemoteObject processBA;
    public static boolean processGlobalsRun;
    public static RemoteObject myClass;
    public static RemoteObject remoteMe;
	public starter() {
		mostCurrent = this;
	}
    public RemoteObject getRemoteMe() {
        return remoteMe;    
    }
    
public boolean isSingleton() {
		return true;
	}
    static {
        anywheresoftware.b4a.pc.RapidSub.moduleToObject.put(new B4XClass("starter"), "com.pocket.paperReader.starter");
	}
     public static RemoteObject getObject() {
		return myClass;
	 }
	public RemoteObject _service;
    private PCBA pcBA;

	public PCBA create(Object[] args) throws ClassNotFoundException{
		processBA = (RemoteObject) args[1];
        _service = (RemoteObject) args[2];
        remoteMe = RemoteObject.declareNull("com.pocket.paperReader.starter");
        anywheresoftware.b4a.keywords.Common.Density = (Float)args[3];
		pcBA = new PCBA(this, starter.class);
        main_subs_0.initializeProcessGlobals();
		return pcBA;
	}public static RemoteObject runMethod(boolean notUsed, String method, Object... args) throws Exception{
		return (RemoteObject) mostCurrent.pcBA.raiseEvent(method.substring(1), args);
	}
    public static void runVoidMethod(String method, Object... args) throws Exception{
		runMethod(false, method, args);
	}
public static RemoteObject __c = RemoteObject.declareNull("anywheresoftware.b4a.keywords.Common");
public static RemoteObject _ui = RemoteObject.declareNull("b4a.uisource.ui");
public static RemoteObject _uxt = RemoteObject.declareNull("b4a.uisource.uxt");
public static RemoteObject _udb = RemoteObject.declareNull("b4a.uisource.udb");
public static RemoteObject _uistyle = RemoteObject.declareNull("b4a.uisource.uistyle");
public static RemoteObject _u3 = RemoteObject.declareNull("b4a.uisource.u3");
public static RemoteObject _patch_createrowviews_bydesc = RemoteObject.declareNull("b4a.uisource.patch_createrowviews_bydesc");
public static RemoteObject _pubdata = RemoteObject.declareNull("b4a.uisource.pubdata");
public static RemoteObject _uipermissionactivity = RemoteObject.declareNull("b4a.uisource.uipermissionactivity");
public static RemoteObject _dateutils = RemoteObject.declareNull("b4a.example.dateutils");
public static com.pocket.paperReader.main _main = null;
  public Object[] GetGlobals() {
		return new Object[] {"DateUtils",starter.mostCurrent._dateutils,"Main",Debug.moduleToString(com.pocket.paperReader.main.class),"patch_createRowViews_byDesc",starter.mostCurrent._patch_createrowviews_bydesc,"pubdata",starter.mostCurrent._pubdata,"Service",starter.mostCurrent._service,"u3",starter.mostCurrent._u3,"udb",starter.mostCurrent._udb,"ui",starter.mostCurrent._ui,"uiPermissionActivity",starter.mostCurrent._uipermissionactivity,"uiStyle",starter.mostCurrent._uistyle,"uxt",starter.mostCurrent._uxt};
}
}