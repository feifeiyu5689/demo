the path should be

C:\_FetchDemo
C:\_FetchDemo\���ReadMe.txt
